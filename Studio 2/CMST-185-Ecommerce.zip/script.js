function submitForm() {
  let size = document.getElementById("Sizes").value;
  let color = document.getElementById("Colors").value;
  let quantity = document.getElementById("Quantity").value;

  let choicesText = "\n";

  if (size === "blank" || color === "blank" || quantity === "blank") {
    let correcth3 = document.getElementById("h3");
    correcth3.innerHTML = "Please fill out all the fields!";
    choicesText += "Please fill out all fields";
  } else {
    choicesText += "Size: " + size + "\n";
    choicesText += "Color: " + color + "\n";
    choicesText += "Quantity: " + quantity + "\n";
  }

  document.getElementById("choicesText").innerText = choicesText;
  openModal();
}

function openModal() {
  document.getElementById("popupModal").style.display = "block";
}

function closeModal() {
  document.getElementById("popupModal").style.display = "none";
}

function generateRandomDate() {
  // Generate a random year between 2000 and 2025
  let year = Math.floor(Math.random() * (2025 - 2000 + 1)) + 2000;

  // Generate a random month between 1 and 12
  let month = Math.floor(Math.random() * 12) + 1;

  // Generate a random day between 1 and 31
  let day = Math.floor(Math.random() * 31) + 1;

  // Generate a random hour between 0 and 23
  let hours = Math.floor(Math.random() * 24);

  let randomDate = new Date(year, month - 1, day, hours);
  return randomDate;
}

// Get the reference to the <p> element
let randomDateDisplay = document.getElementById("randomDateDisplay");

// Example usage
let randomCalendarDate = generateRandomDate();
randomDateDisplay.innerText = "Random Calendar Date: " + randomCalendarDate.toLocaleString();
