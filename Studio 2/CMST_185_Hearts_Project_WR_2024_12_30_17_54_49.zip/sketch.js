let heartWords = [
  "Love U!",
  "XOXO",
  "Be Mine",
  "Awesome",
  "Kiss Me",
  "Peace",
  "You & Me",
  "Luv",
  "Bear Hug",
  "Friend",
];
let textColor = ["black", "white", "red", "black", "cyan"];
let heartColor = ["white", "black", "cyan", "red", "purple"];
let index = 0;
let textIndex = 0;
let colorIndex = 0;
let x = 0;
s = 3;

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);

  let button = createButton("Click For A Surprise!");
  button.position(130, 300);

  // Use the button to change the background color.
  button.mousePressed(() => {
    index = index + 1;
    textIndex = textIndex + 1;
    colorIndex = colorIndex + 1;

    if (index == heartWords.length) {
      index = 0;
    }
    if (textIndex == textColor.length) {
      textIndex = 0;
    }
    if (colorIndex == heartColor.length) {
      colorIndex = 0;
    }
  });
}
function draw() {
  background(220);
  backgroundColor()
  fill(color(heartColor[colorIndex]));
  arc(150, 75, 100, 100, 180, 0);
  arc(250, 75, 100, 100, 180, 0);
  arc(200, 75, 200, 300, -270, 180);
  arc(200, 75, 200, 300, 0, 90);
  
  fill(color(textColor[textIndex]));
  textSize(35);
  textAlign(CENTER);
  text(heartWords[index], 200, 130);
  
  
  bannerHeart()
}
function backgroundColor(){
  for (var x = 0; x <= 400; x += 30) {
    for (var y = 0; y <= 400; y += 30) {
      fill(random(255), 0, random(255));
      arc(x,y,5,5,180,0)
      arc(x+5,y,5,5,180,0)
      arc(x+2.5,y,10,15,-270,180)
      arc(x+2.5,y,10,15,0,90)
    }
  }
}
function bannerHeart(){
  fill(255);
  square(x, 325, 200);
  squareMessage()
  if (x > width || x < -200) {
    s = s * -1;
  }


  x = x + s;

}

function squareMessage(){
  fill(0);
  textStyle(BOLD)
  textSize(15);
  textAlign(LEFT);
  text("Happy Valentines Day!", x+20, 370);
}